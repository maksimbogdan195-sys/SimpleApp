﻿using System;
using System.Windows.Forms;

namespace SimpleApp
{
    public partial class Form1 : Form
    {
        Label label;
        TextBox textBox;
        Button button;

        public Form1()
        {
            InitializeComponent(); // ← ЭТА строка должна быть!

            label = new Label();
            label.Text = "Введите имя:";
            label.Location = new System.Drawing.Point(20, 20);
            label.AutoSize = true;
            Controls.Add(label);

            textBox = new TextBox();
            textBox.Location = new System.Drawing.Point(20, 50);
            Controls.Add(textBox);

            button = new Button();
            button.Text = "OK";
            button.Location = new System.Drawing.Point(20, 90);
            button.Click += Button_Click;
            Controls.Add(button);
        }

        private void Button_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Привет, " + textBox.Text);
        }
    }
}
